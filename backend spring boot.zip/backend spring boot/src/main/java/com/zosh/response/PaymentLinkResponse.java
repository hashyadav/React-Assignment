package com.zosh.response;

import lombok.Data;

@Data
public class PaymentLinkResponse {
	
	private String paymentLink;

}
